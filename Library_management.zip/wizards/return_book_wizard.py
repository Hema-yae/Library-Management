from odoo import models, fields, api


class ReturnBookWizard(models.TransientModel):
    _name = 'return.book.wizard'
    _description = 'Return Book Wizard'

    loan_id = fields.Many2one(
        'library.book.loan',
        string="Loan Transaction",
        required=True
    )

    return_date = fields.Date(
        string="Return Date",
        default=fields.Date.context_today
    )

    fine_amount = fields.Float(
        string="Fine Amount",
        compute="_compute_fine",
        store=False
    )

    @api.depends('return_date', 'loan_id')
    def _compute_fine(self):
        for record in self:
            record.fine_amount = 0.0

            if record.loan_id and record.return_date and record.loan_id.return_date:
                # return_date in loan = due date (your design)
                if record.return_date > record.loan_id.return_date:
                    overdue_days = (record.return_date - record.loan_id.return_date).days
                    record.fine_amount = overdue_days * 100.0  # fine per day

    def action_confirm_return(self):
        self.ensure_one()

        # Prevent double return
        if self.loan_id.status == 'returned':
            return {'type': 'ir.actions.act_window_close'}

        # Update loan record
        self.loan_id.write({
            'status': 'returned',
            'return_date': self.return_date,   # actual return date
            'fine': self.fine_amount
        })

        # Increase available copies safely
        if self.loan_id.book_id:
            self.loan_id.book_id.write({
                'available_copies': self.loan_id.book_id.available_copies + 1
            })

        return {'type': 'ir.actions.act_window_close'}