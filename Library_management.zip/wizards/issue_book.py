from odoo import models, fields, api
from odoo.exceptions import UserError
from datetime import timedelta

class IssueBookWizard(models.TransientModel):
    _name = 'issue.book.wizard'
    _description = 'Issue Book Wizard'

    student_id = fields.Many2one('library.student', string='Student', required=True)
    book_id = fields.Many2one('library.book', string='Book', required=True)
    issue_date = fields.Date(string='Issue Date', default=fields.Date.context_today, required=True)
    due_date = fields.Date(string='Due Date', compute='_compute_due_date', store=True, readonly=False)

    @api.depends('issue_date')
    def _compute_due_date(self):
        for record in self:
            if record.issue_date:
                record.due_date = record.issue_date + timedelta(days=14)

    def action_issue(self):
        self.ensure_one()
        
        # 1. Validation check
        if self.book_id.available_copies <= 0:
            raise UserError("No copies available for this book.")

        # 2. Identify the source: Are we on a Loan record or a Book record?
        active_id = self.env.context.get('active_id')
        active_model = self.env.context.get('active_model')

        # Prepare the data dictionary based on YOUR field names
        vals = {
            'student_id': self.student_id.id,
            'book_id': self.book_id.id,
            'loan_date': self.issue_date,
            'return_date': self.due_date,
            'status': 'issued', # Ensure your field is 'status' and not 'state'
        }

        # 3. UPDATE existing record if we are already in the Loan model
        if active_model == 'library.book.loan' and active_id:
            loan_record = self.env['library.book.loan'].browse(active_id)
            loan_record.write(vals)
        else:
            # CREATE a new record if we opened this from the Book list/form
            self.env['library.book.loan'].create(vals)

        # 4. Update the book inventory
        self.book_id.available_copies -= 1

        return {'type': 'ir.actions.act_window_close'}