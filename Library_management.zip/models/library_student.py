from odoo import models,fields,api

class LibraryStudent    (models.Model):
    _name = 'library.student'
    _description="Student module"

    name = fields.Char(string="Student Name", required=True)
    borrowed_books=fields.Integer(string="Borrowed books count",compute="_compute_borrowed_books",store=True)
    loan_id=fields.One2many('library.book.loan','student_id',string="Loans")
    user_id = fields.Many2one('res.users',string="Related User", help="The Odoo user account for this student")
    
    @api.depends('loan_id')
    def _compute_borrowed_books(self):
        for rec in self:
            rec.borrowed_books=len(rec.loan_id)

    email = fields.Char(string="Email")

    total_fine = fields.Float(
        string="Total Fine", 
        compute="_compute_total_fine", 
        store=True
    )

    @api.depends('loan_id.fine')
    def _compute_total_fine(self):
        for rec in self:
            # We use mapped('fine') to get a list of all fines and then sum them
            rec.total_fine = sum(rec.loan_id.mapped('fine'))

    