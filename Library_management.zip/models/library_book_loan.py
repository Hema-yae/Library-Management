from odoo import models,fields,api
from odoo.exceptions import ValidationError
from datetime import timedelta

class LibraryBookLoan(models.Model):
    _name = 'library.book.loan'
    _description="loan module"

    student_id=fields.Many2one('library.student',string="student",required=True)
    book_id=fields.Many2one('library.book',string="Book",required=True)

    loan_date= fields.Date(string="Loan Date", default=fields.Date.today,required=True)

    return_date= fields.Date(
        string="Return Date", 
        default=lambda self: fields.Date.today() + timedelta(days=14),
        required=True
    )
    status= fields.Selection([
        ('not_issued', 'Not issued'),
        ('issued', 'Issued'),
        ('returned', 'Returned')
    ], string="Status", default='not_issued')

    user_id = fields.Many2one('res.users', string='Borrower', default=lambda self: self.env.user)

    fine=fields.Integer(string="fine",compute='_compute_fine',store=True)

    @api.depends('return_date')
    def _compute_fine(self):
        today=fields.Date.today()
        for rec in self:
            book_count=len(rec.book_id)

            if rec.status != 'returned' and today > rec.return_date:
                rec.fine=book_count*100
            else:
                rec.fine=0        
