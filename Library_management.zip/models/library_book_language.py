from odoo import models,fields,api


class LibraryBookCategory(models.Model):
    _name = 'library.book.language'
    _description = 'Book language'

    name = fields.Char(string="Language", required=True)
    description = fields.Text(string="Language Description")