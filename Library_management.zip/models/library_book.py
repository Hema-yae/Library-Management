from odoo import models, fields, api,   _
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError

class LibraryBook(models.Model):
    _name = "library.book"
    _description = "Library management"

    name = fields.Char(string="Name", required=True)
    category_id = fields.Many2one('library.book.category', string="Category")
    author = fields.Char(string='Author', required=True)
    total_copies = fields.Integer(string="Total Copies", default=1)
    available_copies = fields.Integer(string="Available Copies")
    is_damaged = fields.Boolean(string='Damaged', default=False,help="Check this box if the book is damaged or lost.")
    ref_code = fields.Char(string='Reference Code', required=True, copy=False, readonly=True, index=True, default=lambda self: _('New'))

    status = fields.Selection([
        ('available', 'Available'),
        ('issued', 'Fully Issued'),
        ('damaged', 'Damaged/Lost')
    ], string="Status", compute="_compute_status", store=True)

    isbn = fields.Char(string="ISBN", help="International Standard Book Number")
    language_id = fields.Many2one('library.book.language', string="Language")
    
    @api.depends("is_damaged","available_copies")
    def _compute_status(self):
        for record in self:
            if record.is_damaged:
                record.status = 'damaged'
            elif record.available_copies > 0:
                record.status = 'available'
            else:
                record.status = 'issued'

    def action_issue_book(self):
        self.ensure_one()
        
        # Check if book is even available before opening the wizard
        if self.available_copies <= 0:
            raise UserError("No copies available to issue.")

        # Search for a loan that is NOT 'issued' (e.g., 'draft' or 'not_issued')
        loan = self.env['library.book.loan'].search([
            ('book_id', '=', self.id),
            ('status', 'not in', ['issued', 'returned']) 
        ], order='id desc', limit=1)

        context_vals = {
            'default_book_id': self.id,
        }

        # If a draft loan is found, we link the wizard to that SPECIFIC record
        if loan:
            context_vals.update({
                'default_student_id': loan.student_id.id,
                'active_id': loan.id,
                'active_model': 'library.book.loan',
            })

        return {
            'name': 'Issue Book Wizard',
            'type': 'ir.actions.act_window',
            'res_model': 'issue.book.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': context_vals,
        }
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('ref_code') or vals.get('ref_code') == _('New'):
                # This calls the sequence you created in your XML
                vals['ref_code'] = self.env['ir.sequence'].next_by_code('library.book.ref_code') or _('New')
        
        # Pass the modified list to the parent class
        return super(LibraryBook, self).create(vals_list)

    @api.constrains('total_copies', 'available_copies')
    def _check_copies_positive(self):
        for record in self:
            if record.total_copies < 0:
                raise ValidationError("Total copies cannot be negative!")
            if record.available_copies < 0:
                raise ValidationError("Available copies cannot be negative!")
            if record.available_copies > record.total_copies:
                raise ValidationError("Available copies cannot be greater than Total copies!")    

