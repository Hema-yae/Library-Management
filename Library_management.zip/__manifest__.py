{
    'name': 'library_management',
    'version': '1.0',
    'Summary': 'Library Management',
    'Sequence': 10,
    'author' : 'Hema',
    'description': 'Library Management System',
    'category': 'LMS',
    'website': 'www.google.com',
    'depends': ['base'],
    'data': [
        
        'security/library_security.xml',
        'security/ir.model.access.csv',
        'security/record_rules.xml',
        "data/sequence.xml",

        
        
        'wizards/issue_book_wizard_views.xml',
        'wizards/return_book_wizard_view.xml',
        
        'views/library_book_view.xml',
        'views/library_loan_view.xml',
        'views/library_student_view.xml',
        'views/library_menu.xml',

        

        
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'assets': {},
    'license': 'LGPL-3',

}           